import Mathlib

/-!
# Conservative Matrix Fields

## References

* Raz et al. (2025), "From Euler to AI: Unifying Formulas for Mathematical Constants",
  arXiv:2502.17533
* David & Kaminer (2023), "The conservative matrix field", arXiv:2303.09318
* Blaine et al., Papers 1–3 (unpublished manuscripts)

## Design note on lattice generality

The `CMF` structure takes `e₁ e₂ : Λ` as explicit parameters rather than
bundling them in a typeclass `[CMFLattice Λ]`. This is a deliberate shortcut
valid for the current three papers, which use exactly two lattices:
  - `ℤ × ℤ`   (Papers 1, 2, 3 — standard CMF)
  - `ℤ[i]`    (Paper 1 extension — Gaussian integer base)

If the framework is extended to higher-rank lattices — e.g. `ℤ[ω]` (Eisenstein),
root lattices, or `E₈` — this design must be revisited. At that point the correct
abstraction is a typeclass:

  class CMFLattice (Λ : Type*) [AddCommGroup Λ] where
    generators : Finset Λ
    span_eq_top : ...

and `CMF` should be refactored accordingly. Do not extend the explicit-parameter
design beyond two lattices.

## IsFlat is not a predicate

Flatness (conservativity, discrete curl = 0) is encoded as the `conserv` field
of `CMF`. Every `CMF` is flat by construction. There is no separate `IsFlat`
predicate. Downstream proofs use `F.conserv` directly.
-/

/-- A Conservative Matrix Field on a lattice `Λ` with 2×2 step matrices
    valued in `Matrix (Fin 2) (Fin 2) R`.

    `e₁` and `e₂` are the two generators of the lattice. For `ℤ × ℤ` these
    are `(1,0)` and `(0,1)`; for `ℤ[i]` they are `1` and `i`.

    The conservativity condition is the discrete curl = 0:
    stepping `e₁` then `e₂` gives the same matrix product as
    stepping `e₂` then `e₁`, at every lattice point. -/
structure CMF (Λ : Type*) [AddCommGroup Λ]
              (e₁ e₂ : Λ)
              (R : Type*) [CommRing R] where
  Mx : Λ → Matrix (Fin 2) (Fin 2) R
  My : Λ → Matrix (Fin 2) (Fin 2) R
  conserv : ∀ p : Λ,
    My (p + e₁) * Mx p = Mx (p + e₂) * My p

namespace CMF

/-- Standard CMF on ℤ × ℤ with generators (1,0) and (0,1). -/
abbrev ZZ (R : Type*) [CommRing R] :=
  CMF (ℤ × ℤ) (1, 0) (0, 1) R

end CMF
