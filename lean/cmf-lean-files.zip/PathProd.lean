import Mathlib
import RequestProject.CMF

/-!
# Path products for CMFs on ℤ²

This file defines lattice paths, their matrix products, and the structural
lemmas needed to prove path independence.

## Migration note

`DiscreteConnection R` (from Main.lean) is retired. All results are stated
for `CMF.ZZ R` — the standard CMF on ℤ × ℤ.

`IsFlat` (from Main.lean) is retired. Flatness is the `conserv` field of
any `CMF`. It holds by construction for every term of type `CMF.ZZ R`.
All former `(hF : IsFlat F)` hypotheses are deleted.
-/

namespace CMF

/-- Direction of a single lattice step on ℤ². -/
inductive Step : Type
  | X : Step   -- step in the e₁ = (1,0) direction
  | Y : Step   -- step in the e₂ = (0,1) direction

variable {R : Type*} [CommRing R] (F : ZZ R)

/-! ## Fold state -/

/-- The full state carried through the fold: current position and
    accumulated matrix product.
    The initial state is `(start, 1)`. -/
def pathStateFull (start : ℤ × ℤ) (steps : List Step) :
    (ℤ × ℤ) × Matrix (Fin 2) (Fin 2) R :=
  steps.foldl
    (fun (state : (ℤ × ℤ) × Matrix (Fin 2) (Fin 2) R) step =>
      match step with
      | Step.X => (state.1 + (1, 0), F.Mx state.1 * state.2)
      | Step.Y => (state.1 + (0, 1), F.My state.1 * state.2))
    (start, 1)

/-! ## Derived projections -/

/-- The lattice point reached after following `steps` from `start`. -/
def pathEnd (start : ℤ × ℤ) (steps : List Step) : ℤ × ℤ :=
  (F.pathStateFull start steps).1

/-- The accumulated matrix product along a path. -/
def pathProd (start : ℤ × ℤ) (steps : List Step) : Matrix (Fin 2) (Fin 2) R :=
  (F.pathStateFull start steps).2

/-! ## Structural lemmas for the fold -/

@[simp]
lemma pathStateFull_nil (start : ℤ × ℤ) :
    F.pathStateFull start [] = (start, 1) := rfl

@[simp]
lemma pathStateFull_cons_X (start : ℤ × ℤ) (steps : List Step) :
    F.pathStateFull start (Step.X :: steps) =
    F.pathStateFull (start + (1, 0)) steps |>.map id (F.Mx start * ·) := by
  simp [pathStateFull, List.foldl_cons]
  sorry -- migrate from Main.lean

@[simp]
lemma pathStateFull_cons_Y (start : ℤ × ℤ) (steps : List Step) :
    F.pathStateFull start (Step.Y :: steps) =
    F.pathStateFull (start + (0, 1)) steps |>.map id (F.My start * ·) := by
  simp [pathStateFull, List.foldl_cons]
  sorry -- migrate from Main.lean

/-- Appending two paths: the full state factors at the join. -/
lemma pathStateFull_append (start : ℤ × ℤ) (p q : List Step) :
    F.pathStateFull start (p ++ q) =
    let mid := (F.pathStateFull start p)
    ((F.pathStateFull mid.1 q).1,
     (F.pathStateFull mid.1 q).2 * mid.2) := by
  simp [pathStateFull, List.foldl_append]
  sorry -- migrate from Main.lean

/-- The position component of `pathStateFull` does not depend on the
    initial matrix accumulator. -/
lemma pathStateFull_fst_indep_snd (start : ℤ × ℤ) (steps : List Step) :
    (F.pathStateFull start steps).1 = F.pathEnd start steps := rfl

/-- The matrix component is left-linear in the initial accumulator:
    starting with `A` instead of `1` scales the result on the right. -/
lemma pathStateFull_snd_mul (start : ℤ × ℤ) (steps : List Step)
    (A : Matrix (Fin 2) (Fin 2) R) :
    (steps.foldl
      (fun (state : (ℤ × ℤ) × Matrix (Fin 2) (Fin 2) R) step =>
        match step with
        | Step.X => (state.1 + (1, 0), F.Mx state.1 * state.2)
        | Step.Y => (state.1 + (0, 1), F.My state.1 * state.2))
      (start, A)).2 =
    F.pathProd start steps * A := by
  sorry -- migrate from Main.lean

/-! ## Corollaries -/

@[simp]
lemma pathEnd_nil (start : ℤ × ℤ) : F.pathEnd start [] = start := rfl

@[simp]
lemma pathProd_nil (start : ℤ × ℤ) : F.pathProd start [] = 1 := rfl

/-- The matrix product of a concatenated path splits at the join.
    Multiplication is right-to-left: the suffix product left-multiplies
    the prefix product. -/
lemma pathProd_append (start : ℤ × ℤ) (p q : List Step) :
    F.pathProd start (p ++ q) =
    F.pathProd (F.pathEnd start p) q * F.pathProd start p := by
  simp [pathProd, pathEnd, pathStateFull_append, pathStateFull_snd_mul]

/-- The endpoint after concatenation is the endpoint of the second
    path started from the endpoint of the first. -/
lemma pathEnd_append (start : ℤ × ℤ) (p q : List Step) :
    F.pathEnd start (p ++ q) = F.pathEnd (F.pathEnd start p) q := by
  simp [pathEnd, pathStateFull_append]

/-- The endpoint is determined solely by the count of X and Y steps. -/
lemma pathEnd_eq_start_add_counts (start : ℤ × ℤ) (steps : List Step) :
    F.pathEnd start steps =
    start + (steps.count Step.X, steps.count Step.Y) := by
  induction steps with
  | nil => simp
  | cons s rest ih =>
    cases s <;> simp [pathEnd, pathStateFull, ih, Step.X, Step.Y] <;> ring

end CMF
