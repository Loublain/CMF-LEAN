import Mathlib
import RequestProject.CMF
import RequestProject.CMF.PathProd

/-!
# Path independence for CMFs on ℤ²

## Main results

* `flat_iff_square` — `conserv` is equivalent to path-independence on
  elementary unit squares
* `swap_XY` — swapping an adjacent `[X,Y]` to `[Y,X]` anywhere in a
  path preserves the matrix product
* `canonicalPath` — every path has a canonical form: all X steps then
  all Y steps
* `canonical_preserves_prod` — a path and its canonical form have the
  same matrix product
* `path_independent` — any two paths with the same start and end point
  have the same matrix product

## Strategy

  path_independent
         │
         ├── canonical_preserves_prod
         │          │
         │          └── swap_XY
         │                    │
         │                    └── flat_iff_square ← conserv ✓
         │
         └── same_endpoint_same_counts
                    │
                    └── pathEnd_eq_start_add_counts ✓
-/

namespace CMF

variable {R : Type*} [CommRing R] (F : ZZ R)

/-! ## Elementary square -/

/-- `conserv` is equivalent to path-independence on unit squares:
    going right-then-up equals going up-then-right. -/
lemma flat_iff_square :
    (∀ p : ℤ × ℤ,
      F.pathProd p [Step.X, Step.Y] = F.pathProd p [Step.Y, Step.X]) ↔
    (∀ p : ℤ × ℤ,
      F.My (p + (1, 0)) * F.Mx p = F.Mx (p + (0, 1)) * F.My p) := by
  constructor
  · intro h p
    have := h p
    simp [pathProd, pathStateFull] at this
    exact this
  · intro h p
    simp [pathProd, pathStateFull]
    exact h p

/-- `conserv` gives path-independence on unit squares directly. -/
lemma square_comm (p : ℤ × ℤ) :
    F.pathProd p [Step.X, Step.Y] = F.pathProd p [Step.Y, Step.X] :=
  flat_iff_square.mpr F.conserv p

/-! ## The swap lemma -/

/-- Swapping an adjacent `[X,Y]` to `[Y,X]` anywhere in a path
    preserves both the endpoint and the matrix product. -/
lemma swap_XY (start : ℤ × ℤ) (pre post : List Step) :
    F.pathProd start (pre ++ [Step.X, Step.Y] ++ post) =
    F.pathProd start (pre ++ [Step.Y, Step.X] ++ post) := by
  -- walk `pre`, arrive at p'
  set p' := F.pathEnd start pre with hp'
  -- factor off pre on both sides
  simp only [List.append_assoc, pathProd_append]
  -- the two swapped cores produce the same product at p'
  have hprod : F.pathProd p' [Step.X, Step.Y] =
               F.pathProd p' [Step.Y, Step.X] := F.square_comm p'
  -- they also end at the same position
  have hend : F.pathEnd p' [Step.X, Step.Y] =
              F.pathEnd p' [Step.Y, Step.X] := by
    simp [pathEnd, pathStateFull, add_comm]
  -- rewrite; post is identical on both sides
  rw [hprod, hend]

/-! ## Canonical paths -/

/-- The canonical form of a path: all X steps first, then all Y steps.
    Determined entirely by the count of each step type. -/
def canonicalPath (steps : List Step) : List Step :=
  List.replicate (steps.count Step.X) Step.X ++
  List.replicate (steps.count Step.Y) Step.Y

/-- The canonical path has the same X count as the original. -/
@[simp]
lemma canonicalPath_count_X (steps : List Step) :
    (canonicalPath steps).count Step.X = steps.count Step.X := by
  simp [canonicalPath, List.count_append, List.count_replicate]

/-- The canonical path has the same Y count as the original. -/
@[simp]
lemma canonicalPath_count_Y (steps : List Step) :
    (canonicalPath steps).count Step.Y = steps.count Step.Y := by
  simp [canonicalPath, List.count_append, List.count_replicate]

/-- The canonical path reaches the same endpoint as the original. -/
lemma canonicalPath_pathEnd (start : ℤ × ℤ) (steps : List Step) :
    F.pathEnd start (canonicalPath steps) = F.pathEnd start steps := by
  simp [pathEnd_eq_start_add_counts, canonicalPath]

/-! ## Bubble sort by inversions -/

/-- An inversion is a Y appearing before an X in the path.
    This is the termination measure for the sorting argument. -/
def inversions (steps : List Step) : ℕ :=
  (steps.enum.filter (fun ⟨i, s⟩ =>
    s = Step.Y &&
    (steps.drop (i + 1)).any (· = Step.X))).length

/-- Bubbling a single Y leftward past all trailing X steps preserves
    the matrix product. Induction on the suffix. -/
lemma bubble_Y_past_Xs (start : ℤ × ℤ) (n : ℕ) (post : List Step) :
    F.pathProd start
      ([Step.Y] ++ List.replicate n Step.X ++ post) =
    F.pathProd start
      (List.replicate n Step.X ++ [Step.Y] ++ post) := by
  induction n with
  | zero => simp
  | succ k ih =>
    -- [Y, X, X^k, post] → [X, Y, X^k, post] by swap_XY at []
    -- then [X, Y, X^k, post] → [X, X^k, Y, post] by ih starting at p+(1,0)
    rw [List.replicate_succ, ← List.append_assoc,
        ← List.append_assoc]
    rw [show [Step.Y] ++ Step.X :: List.replicate k Step.X =
            [] ++ [Step.Y, Step.X] ++ List.replicate k Step.X by simp]
    rw [F.swap_XY start [] (List.replicate k Step.X ++ post)]
    simp only [List.nil_append, List.append_assoc]
    rw [pathProd_append, pathProd_append]
    congr 1
    · -- suffix from p+(1,0): [Y, X^k, post] → [X^k, Y, post]
      have : F.pathEnd start [Step.X] = start + (1, 0) := by
        simp [pathEnd, pathStateFull]
      rw [this]
      exact ih (start + (1, 0))
    · rfl

/-- Every path has the same matrix product as its canonical form. -/
lemma canonical_preserves_prod (start : ℤ × ℤ) (steps : List Step) :
    F.pathProd start steps = F.pathProd start (canonicalPath steps) := by
  induction steps with
  | nil => simp [canonicalPath]
  | cons s rest ih =>
    cases s with
    | X =>
      -- X :: rest → X :: canonical(rest) → canonical(X :: rest)
      simp only [canonicalPath, List.count_cons, List.count_cons_self,
                 List.count_cons_of_ne (by decide)]
      rw [pathProd_append, pathProd_append]
      simp only [pathEnd_eq_start_add_counts]
      congr 1
      exact ih (start + (1, 0))
    | Y =>
      -- Y :: rest → Y :: X^countX(rest) ++ Y^countY(rest)
      -- then bubble Y past the X's
      simp only [canonicalPath, List.count_cons, List.count_cons_self,
                 List.count_cons_of_ne (by decide)]
      rw [show List.replicate (rest.count Step.X) Step.X ++
              List.replicate (rest.count Step.Y + 1) Step.Y =
          List.replicate (rest.count Step.X) Step.X ++
              [Step.Y] ++ List.replicate (rest.count Step.Y) Step.Y by
        simp [List.replicate_succ, List.append_assoc]]
      rw [← bubble_Y_past_Xs F start (rest.count Step.X)
            (List.replicate (rest.count Step.Y) Step.Y)]
      simp only [List.singleton_append, List.append_assoc]
      rw [pathProd_append]
      simp only [pathEnd_nil, pathStateFull]
      rw [show F.pathProd start (Step.Y :: rest) =
              F.pathProd (start + (0,1)) rest |>.mul_left (F.My start) from by
        simp [pathProd, pathStateFull]]
      congr 1
      exact ih (start + (0, 1))

/-! ## Path independence -/

/-- Two paths with the same endpoint have the same X and Y counts. -/
lemma same_endpoint_same_counts (start : ℤ × ℤ) (p q : List Step)
    (h : F.pathEnd start p = F.pathEnd start q) :
    p.count Step.X = q.count Step.X ∧
    p.count Step.Y = q.count Step.Y := by
  simp [pathEnd_eq_start_add_counts] at h
  exact ⟨by linarith [h.1], by linarith [h.2]⟩

/-- **Path independence**: any two paths from the same start to the same
    end point have the same matrix product. -/
theorem path_independent (start : ℤ × ℤ) (p q : List Step)
    (hend : F.pathEnd start p = F.pathEnd start q) :
    F.pathProd start p = F.pathProd start q := by
  rw [F.canonical_preserves_prod start p,
      F.canonical_preserves_prod start q]
  obtain ⟨hx, hy⟩ := F.same_endpoint_same_counts start p q hend
  simp [canonicalPath, hx, hy]

end CMF
